package com.salesianostriana.dam.GermanPastorMolero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GermanPastorMoleroApplicationTests {

	@Test
	void contextLoads() {
	}

}
