package com.salesianostriana.dam.GermanPastorMolero.model;

public enum EstadoVivienda {

    NUEVA,SEGUNDA_MANO,REFORMAR
}
