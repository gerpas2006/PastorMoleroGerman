package com.salesianostriana.dam.GermanPastorMolero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GermanPastorMoleroApplication {

	public static void main(String[] args) {
		SpringApplication.run(GermanPastorMoleroApplication.class, args);
	}

}
