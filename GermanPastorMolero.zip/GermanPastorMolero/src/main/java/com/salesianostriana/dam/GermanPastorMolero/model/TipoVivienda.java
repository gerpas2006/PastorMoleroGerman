package com.salesianostriana.dam.GermanPastorMolero.model;

public enum TipoVivienda {

    PISO,CASA,ATICO,DUPLEX,CHALET
}
