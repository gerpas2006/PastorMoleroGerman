package com.salesianostriana.dam.PastorMoleroGerman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PastorMoleroGermanApplicationTests {

	@Test
	void contextLoads() {
	}

}
